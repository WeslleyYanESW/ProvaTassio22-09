package br.edu.universidadedevassouras.prova.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Endereco {

    @Column(nullable = false)
    private String CEP;

    @Column(nullable = false)
    private String Tipo_Logradouro;


    @Column(nullable = false)
    private String Logradouro;

    @Column(nullable = false)
    private String Número;

    @Column(nullable = false)
    private String Bairro;

    @Column(nullable = false)
    private String Cidade;

    @Column(nullable = false)
    private String Estado;

    @Column(nullable = false)
    private String Pais;


}
