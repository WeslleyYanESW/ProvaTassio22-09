package br.edu.universidadedevassouras.prova.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Pessoa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private String Email;

    @Column(nullable = false)
    private String Data_de_Nascimento;

    @Column(nullable = false)
    private String Sexo;

    @Column(nullable = false)
    private String CPF;

    @Column(nullable = false)
    private String RG;

    @Column(nullable = false)
    private String Tipo_Sanguíneo;

    @Column(nullable = false)
    private String Pai;

    @Column(nullable = false)
    private String Mãe;

    @Column(nullable = false)
    private String Telefone;

    @Column(nullable = false)
    private String Endereço;

}