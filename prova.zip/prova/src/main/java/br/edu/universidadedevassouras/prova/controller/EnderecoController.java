package br.edu.universidadedevassouras.prova.controller;

import br.edu.universidadedevassouras.prova.model.Endereco;
import br.edu.universidadedevassouras.prova.repository.EnderecoRepository;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
public class EnderecoController {
    @Autowired
    private EnderecoRepository _enderecoRepository;

    @RequestMapping(value = "/endereco", method = RequestMethod.GET)
    public List<Endereco> Get() {
        return _enderecoRepository.findAll();
    }

    @RequestMapping(value = "/endereco/{name}", method = RequestMethod.GET)
    public ResponseEntity<Endereco> GetById(@PathVariable(value = "Logradouro") String Logradouro) {
        Optional<Endereco> endereco = _enderecoRepository.findByName(Logradouro);
        if (endereco.isPresent())
            return new ResponseEntity<Endereco>(endereco.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/endereco", method = RequestMethod.POST)
    public Endereco Post(@Valid @RequestBody Endereco endereco) {
        return _enderecoRepository.save(endereco);
    }

    @RequestMapping(value = "/endereco/{name}", method = RequestMethod.PUT)
    public ResponseEntity<Endereco> Put(@PathVariable(value = "Logradouro") String Logradouro, @Valid @RequestBody Endereco newEndereco) {
        Optional<Endereco> oldEndereco = _enderecoRepository.findByName(Logradouro);
        if (oldEndereco.isPresent()) {
            Endereco endereco = oldEndereco.get();
            endereco.setLogradouro(newEndereco.getLogradouro());
            _enderecoRepository.save(endereco);
            return new ResponseEntity<Endereco>(endereco, HttpStatus.OK);
        } else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/endereco/{name}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> Delete(@PathVariable(value = "Logradouro") String Logradouro) {
        Optional<Endereco> endereco = _enderecoRepository.findByName(Logradouro);
        if (endereco.isPresent()) {
            _enderecoRepository.delete(endereco.get());
            return new ResponseEntity<>(HttpStatus.OK);
        } else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

}

