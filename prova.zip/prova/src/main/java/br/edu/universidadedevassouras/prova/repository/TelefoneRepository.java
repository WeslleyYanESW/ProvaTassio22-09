package br.edu.universidadedevassouras.prova.repository;

import br.edu.universidadedevassouras.prova.model.Telefone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TelefoneRepository extends JpaRepository<Telefone, Long> {
    Optional<Telefone> findByName(String celular, String fixo);
}