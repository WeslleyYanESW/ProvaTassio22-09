package br.edu.universidadedevassouras.prova.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Telefone {


    @Column(nullable = false)
    private String Celular;

    @Column(nullable = false)
    private String Fixo;


}
